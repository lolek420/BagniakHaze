edited by # Tayogod#3841

skrypcik na bagniaka mozecie sobie strzelac bez recoila podczas effektu, pozdrawiam 
pytania na dc.

wklej to do bazy danych 

          |
          |
          |
         \ /


INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES

    ('bagniak', 'Bagniak Haze', 1, 0, 1)    

;
