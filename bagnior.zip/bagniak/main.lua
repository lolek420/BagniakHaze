-- TayoGOD#3841

ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterUsableItem('bagniak', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerClientEvent('acidtrip:weed', source)
	xPlayer.removeInventoryItem('bagniak', 1)
end)